﻿namespace StoreDB
{


    partial class StoreDBDataSet
    {
    }
}



